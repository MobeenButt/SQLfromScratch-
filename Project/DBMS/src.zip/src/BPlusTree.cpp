#include "BPlusTree.h"
#include <iostream>

BPlusTree::Node::Node(bool leaf) : isLeaf(leaf), nextLeaf(nullptr) {}


json BPlusTree::Node::serialize() {
    json j;
    j["isLeaf"] = isLeaf;
    j["keys"] = keys;
    j["values"] = values;
    j["nextLeaf"] = (nextLeaf != nullptr);
    return j;
}

BPlusTree::Node* BPlusTree::Node::deserialize(const json& j) {
    Node* node = new Node(j["isLeaf"]);
    node->keys = j["keys"].get<std::vector<int>>();
    node->values = j["values"].get<std::vector<std::string>>();
    return node;
}

BPlusTree::BPlusTree() {
    root = new Node(true);
    loadFromFile(); // Load existing data
}

BPlusTree::~BPlusTree() {
    saveToFile(); // Save before exiting
}

void BPlusTree::insert(int key, std::string value) {
    Node* leaf = root;
    while (!leaf->isLeaf) {
        int i = 0;
        while (i < leaf->keys.size() && key > leaf->keys[i]) i++;
        leaf = leaf->children[i];
    }

    leaf->keys.push_back(key);
    leaf->values.push_back(value);
    splitLeaf(leaf);
    saveToFile();
}



std::string BPlusTree::search(int key) {
    Node* leaf = root;
    while (!leaf->isLeaf) {
        int i = 0;
        while (i < leaf->keys.size() && key > leaf->keys[i]) i++;
        leaf = leaf->children[i];
    }

    for (int i = 0; i < leaf->keys.size(); i++)
        if (leaf->keys[i] == key)
            return leaf->values[i];

    return "Not Found";
}

void BPlusTree::saveToFile() {
    std::ofstream file("bplustree.json");
    json j;
    j["root"] = root->serialize();
    file << j.dump(4);
}

void BPlusTree::loadFromFile() {
    std::ifstream file("bplustree.json");
    if (!file) return;
    json j;
    file >> j;
    root = Node::deserialize(j["root"]);
}

void BPlusTree::printTree() {
    Node* curr = root;
    while (!curr->isLeaf)
        curr = curr->children[0];

    while (curr) {
        for (int k : curr->keys)
            std::cout << k << " ";
        std::cout << " | ";
        curr = curr->nextLeaf;
    }
    std::cout << std::endl;
}
